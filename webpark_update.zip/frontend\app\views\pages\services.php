<?php
declare(strict_types=1);
$categories = is_array($categories ?? null) ? $categories : [];
$activeCategorySlug = (string) ($activeCategorySlug ?? 'all');
$fallbackImage = asset_url('images/story.png');
$heroImage = asset_url('images/services-hero-bg.png');
$ctaImage = asset_url('images/bg-cta.jpg');
/**
 * Services listing page — grid 2-column card layout.
 *
 * Layout  : Hero Section + heading + 2-column card grid + CTA
 * ข้อมูล  : $mockServices (เปลี่ยนเป็น DB query ได้ภายหลัง)
 * รูป     : ใช้ image_placeholder เดิมจาก mockServices
 */
 $mockServices = [
    [
        'id'                => 1,
        'icon_emoji'        => '🖥️',
        'title'             => 'ERP / ERM',
        'summary'           => getCurrentLang() === 'th' ? 'พัฒนาระบบบริหารจัดการองค์กร เพื่อเพิ่มประสิทธิภาพการทำงาน เชื่อมโยงข้อมูล และรองรับการเติบโตของธุรกิจ' : 'Develop enterprise management systems to increase efficiency, connect data, and support business growth.',
        'image_placeholder' => 'images/erp.png',
        'dropdown_title'    => 'ERP / ERM / HR',
        'subcategories'     => [
            ['label' => 'ERP System',           'href' => route_url('/erp')],
            ['label' => 'Accounting & Finance', 'href' => route_url('/article', ['id' => 39])],
            ['label' => 'Sales / Purchase',     'href' => route_url('/article', ['id' => 40])],
            ['label' => 'Inventory / Warehouse','href' => route_url('/article', ['id' => 41])],
            ['label' => 'Customer Management',  'href' => route_url('/article', ['id' => 42])],
            ['label' => 'Lead Management',      'href' => '#'],
            ['label' => 'Customer Service',     'href' => route_url('/article', ['id' => 29])],
            ['label' => 'Partner / Supplier Management', 'href' => route_url('/article', ['id' => 30])],
            ['label' => 'HRM System',           'href' => route_url('/article', ['id' => 31])],
            ['label' => 'Attendance / Leave',   'href' => route_url('/article', ['id' => 32])],
            ['label' => 'Payroll',              'href' => route_url('/article', ['id' => 14])],
            ['label' => 'Workflow Approval',    'href' => route_url('/article', ['id' => 34])],
        ],
    ],
    [
        'id'                => 2,
        'slug'              => 'digital-platform',
        'detail_url'        => route_url('/services/digital-platform'),
        'icon_emoji'        => '🌐',
        'title'             => getCurrentLang() === 'th' ? 'แพลตฟอร์มดิจิทัล' : 'Platform Digital',
        'summary'           => getCurrentLang() === 'th' ? 'ออกแบบและพัฒนาแพลตฟอร์มดิจิทัล เว็บไซต์ และระบบธุรกิจออนไลน์ที่ใช้งานง่าย ยืดหยุ่น และตอบโจทย์องค์กร' : 'Design and develop digital platforms, websites, and online business systems that are user-friendly, flexible, and meet organizational needs.',
        'image_placeholder' => 'images/bg-cta.jpg',
        'dropdown_title'    => 'Platform / Communication / Data',
        'subcategories'     => [
            ['label' => getCurrentLang() === 'th' ? 'โซลูชันแพลตฟอร์มดิจิทัลทั้งหมด (10 โซลูชัน)' : 'All 10 Platform Solutions', 'href' => route_url('/services/digital-platform#dp-solutions')],
            ['label' => 'Website / Responsive / CMS',    'href' => route_url('/article', ['id' => 35])],
            ['label' => 'Mobile App / Mobile Site',      'href' => route_url('/article', ['id' => 36])],
            ['label' => 'E-commerce',                    'href' => route_url('/article', ['id' => 37])],
            ['label' => 'Custom Web Application',        'href' => '#'],
            ['label' => 'Membership / Portal System',    'href' => '#'],
            ['label' => 'SMS Service',                   'href' => '#'],
            ['label' => 'Email Marketing',               'href' => '#'],
            ['label' => 'Chatbot / Live Chat',           'href' => '#'],
            ['label' => 'Game / Interactive Campaign',   'href' => '#'],
            ['label' => 'Big Data',                      'href' => '#'],
            ['label' => 'E-learning',                    'href' => '#'],
            ['label' => 'Dashboard',                     'href' => '#'],
            ['label' => 'Data Management',               'href' => '#'],
        ],
    ],
    [
        'id'                => 3,
        'slug'              => 'online-marketing',
        'detail_url'        => route_url('/services/online-marketing'),
        'icon_emoji'        => '📣',
        'title'             => getCurrentLang() === 'th' ? 'การตลาดออนไลน์' : 'Online Marketing',
        'title_en'          => 'Online Marketing',
        'summary'           => getCurrentLang() === 'th' ? 'วางกลยุทธ์การตลาดออนไลน์ เพื่อเพิ่มการมองเห็น สร้างโอกาสทางธุรกิจ และเพิ่มยอดขายได้อย่างวัดผลได้จริง' : 'Plan online marketing strategies to increase visibility, create business opportunities, and measurably increase sales.',
        'image_placeholder' => 'images/bg-hand.jpg',
        'dropdown_title'    => 'Strategy / Performance / Content',
        'subcategories'     => [
            ['label' => getCurrentLang() === 'th' ? 'โซลูชันการตลาดออนไลน์ทั้งหมด (10 โซลูชัน)' : 'All 10 Marketing Solutions', 'href' => route_url('/services/online-marketing#om-solutions')],
            ['label' => 'Digital Marketing Consultant',  'href' => route_url('/services/online-marketing#om-solutions')],
            ['label' => 'Media Planner / PR & Media Strategy', 'href' => route_url('/services/online-marketing#om-solutions')],
            ['label' => 'SEO',                           'href' => route_url('/services/online-marketing#om-solutions')],
            ['label' => 'Social Network',                'href' => route_url('/services/online-marketing#om-solutions')],
            ['label' => 'Online Campaign',               'href' => route_url('/services/online-marketing#om-solutions')],
            ['label' => 'Monitoring & Analysis',         'href' => route_url('/services/online-marketing#om-solutions')],
            ['label' => 'Campaign Performance Report',   'href' => route_url('/services/online-marketing#om-solutions')],
            ['label' => 'Return on Investment (ROI)',    'href' => route_url('/services/online-marketing#om-solutions')],
            ['label' => 'Productivity Analysis',         'href' => route_url('/services/online-marketing#om-solutions')],
            ['label' => 'Content Strategy',              'href' => route_url('/services/online-marketing#om-solutions')],
            ['label' => 'Ads Management',                'href' => route_url('/services/online-marketing#om-solutions')],
            ['label' => 'Social Media Content',          'href' => route_url('/services/online-marketing#om-solutions')],
            ['label' => 'Search Engine Marketing',       'href' => route_url('/services/online-marketing#om-solutions')],
        ],
    ],
    [
        'id'                => 4,
        'slug'              => 'creative-design',
        'detail_url'        => route_url('/services/creative-design'),
        'icon_emoji'        => '🎨',
        'title'             => getCurrentLang() === 'th' ? 'ออกแบบสร้างสรรค์' : 'Creative / Design',
        'title_en'          => 'Creative / Design',
        'summary'           => getCurrentLang() === 'th' ? 'สร้างสรรค์งานออกแบบดิจิทัลและคอนเทนต์ที่ช่วยสื่อสารแบรนด์ ทั้ง UI/UX, Graphic, Motion และสื่อสารแบรนด์' : 'Create digital designs and content that help communicate your brand, including UI/UX, Graphic, Motion, and brand communication.',
        'image_placeholder' => 'images/women-office.jpg',
        'dropdown_title'    => 'Design / Motion / Media',
        'subcategories'     => [
            ['label' => getCurrentLang() === 'th' ? 'โซลูชันการออกแบบทั้งหมด (10 โซลูชัน)' : 'All 10 Creative Solutions', 'href' => route_url('/services/creative-design#cd-solutions')],
            ['label' => 'Brand Identity',                'href' => route_url('/services/creative-design#cd-solutions')],
            ['label' => 'Web Design',                    'href' => route_url('/services/creative-design#cd-solutions')],
            ['label' => 'UX/UI Design',                  'href' => route_url('/services/creative-design#cd-solutions')],
            ['label' => 'Graphic Design',                'href' => route_url('/services/creative-design#cd-solutions')],
            ['label' => 'Social Media Creative',         'href' => route_url('/services/creative-design#cd-solutions')],
            ['label' => 'Motion Graphic / Video',        'href' => route_url('/services/creative-design#cd-solutions')],
            ['label' => 'Present & Sales Kit',           'href' => route_url('/services/creative-design#cd-solutions')],
            ['label' => 'Packaging Design',              'href' => route_url('/services/creative-design#cd-solutions')],
            ['label' => 'Content Visual System',         'href' => route_url('/services/creative-design#cd-solutions')],
            ['label' => 'Design System',                 'href' => route_url('/services/creative-design#cd-solutions')],
        ],
    ],
];
// Merge database services with mock subcategories
if (isset($services) && is_array($services)) {
    $mergedServices = [];
    foreach ($services as $dbService) {
        $slug = $dbService['slug'];
        $mockMatch = null;
        if ($slug === 'erp-erm' || str_contains(strtolower($dbService['title']), 'erp')) {
            $mockMatch = $mockServices[0];
        } elseif ($slug === 'digital-platform' || str_contains(strtolower($dbService['title']), 'digital')) {
            $mockMatch = $mockServices[1];
        } elseif ($slug === 'online-marketing' || str_contains(strtolower($dbService['title']), 'marketing')) {
            $mockMatch = $mockServices[2];
        } elseif ($slug === 'creative-design' || str_contains(strtolower($dbService['title']), 'creative')) {
            $mockMatch = $mockServices[3];
        } else {
            $mockMatch = $mockServices[0];
        }
        // Get features from the model which now loads from service_features table
        $dbFeatures = $dbService['features'] ?? [];
        $mappedSubcategories = [];
        if (!empty($dbFeatures)) {
            foreach ($dbFeatures as $feature) {
                if (empty(trim($feature))) continue;
                // Keep the ERP link for ERP System, else use #
                $href = ($slug === 'erp-erm' && $feature === 'ERP System') ? route_url('/erp') : '#';
                // --- ONLINE MARKETING ---
                if (str_contains(strtolower($feature), 'seo')) $href = route_url('/article-detail-mockup');
                if (str_contains(strtolower($feature), 'payroll')) $href = route_url('/article', ['id' => 14]);
                if (str_contains(strtolower($feature), 'motion')) $href = route_url('/article', ['id' => 14]);
                // --- ERP / ERM / HR ---
                if (str_contains(strtolower($feature), 'customer service')) $href = route_url('/article', ['id' => 29]);
                if (str_contains(strtolower($feature), 'partner')) $href = route_url('/article', ['id' => 30]);
                if (str_contains(strtolower($feature), 'hrm')) $href = route_url('/article', ['id' => 31]);
                if (str_contains(strtolower($feature), 'attendance')) $href = route_url('/article', ['id' => 32]);
                if (str_contains(strtolower($feature), 'workflow')) $href = route_url('/article', ['id' => 34]);
                if (str_contains(strtolower($feature), 'accounting')) $href = route_url('/article', ['id' => 39]);
                if (str_contains(strtolower($feature), 'sales')) $href = route_url('/article', ['id' => 40]);
                if (str_contains(strtolower($feature), 'inventory')) $href = route_url('/article', ['id' => 41]);
                if (str_contains(strtolower($feature), 'customer management')) $href = route_url('/article', ['id' => 42]);
                // --- DIGITAL PLATFORMS ---
                if (str_contains(strtolower($feature), 'website')) $href = route_url('/article', ['id' => 35]);
                if (str_contains(strtolower($feature), 'mobile')) $href = route_url('/article', ['id' => 36]);
                if (str_contains(strtolower($feature), 'e-commerce') || str_contains(strtolower($feature), 'ecommerce')) $href = route_url('/article', ['id' => 37]);
                if (($slug === 'digital-platform' || str_contains(strtolower($dbService['title']), 'digital')) && $href === '#') {
                    $href = route_url('/services/digital-platform');
                }
                if (($slug === 'online-marketing' || str_contains(strtolower($dbService['title']), 'marketing') || str_contains(strtolower($dbService['title']), 'การตลาด') || str_contains(strtolower($dbService['title']), 'online')) && $href === '#') {
                    $href = route_url('/services/online-marketing#om-solutions');
                }
                if (($slug === 'creative-design' || str_contains(strtolower($dbService['title']), 'creative') || str_contains(strtolower($dbService['title']), 'design') || str_contains(strtolower($dbService['title']), 'สร้างสรรค์') || str_contains(strtolower($dbService['title']), 'ออกแบบ')) && $href === '#') {
                    $href = route_url('/services/creative-design#cd-solutions');
                }
                $mappedSubcategories[] = [
                    'label' => $feature,
                    'href' => $href
                ];
            }
        }
        // Fallback to mock data if database features are empty or corrupted by invalid JSON
        if (empty($mappedSubcategories)) {
            $mappedSubcategories = $mockMatch['subcategories'] ?? [];
        }
        $isDigital = ($slug === 'digital-platform' || str_contains(strtolower($dbService['title']), 'digital') || str_contains(strtolower($dbService['title']), 'แพลตฟอร์ม'));
        $isMarketing = ($slug === 'online-marketing' || str_contains(strtolower($dbService['title']), 'online') || str_contains(strtolower($dbService['title']), 'marketing') || str_contains(strtolower($dbService['title']), 'การตลาด'));
        $isCreative = ($slug === 'creative-design' || str_contains(strtolower($dbService['title']), 'creative') || str_contains(strtolower($dbService['title']), 'design') || str_contains(strtolower($dbService['title']), 'สร้างสรรค์') || str_contains(strtolower($dbService['title']), 'ออกแบบ'));
        
        $title = $dbService['title'];
        if ($isDigital) {
            $title = getCurrentLang() === 'th' ? 'แพลตฟอร์มดิจิทัล' : 'Platform Digital';
        } elseif ($isMarketing) {
            $title = getCurrentLang() === 'th' ? 'การตลาดออนไลน์' : 'Online Marketing';
        } elseif ($isCreative) {
            $title = getCurrentLang() === 'th' ? 'ออกแบบสร้างสรรค์' : 'Creative / Design';
        } elseif (getCurrentLang() === 'en') {
            $title = $mockMatch['title_en'] ?? $mockMatch['title'] ?? $dbService['title'];
        }

        $detailUrl = '#';
        if ($isDigital) {
            $detailUrl = route_url('/services/digital-platform');
        } elseif ($slug === 'erp-erm' || str_contains(strtolower($dbService['title']), 'erp')) {
            $detailUrl = route_url('/erp');
        } elseif ($isMarketing) {
            $detailUrl = route_url('/services/online-marketing');
        } elseif ($isCreative) {
            $detailUrl = route_url('/services/creative-design');
        }

        $mergedServices[] = [
            'id' => $dbService['id'],
            'slug' => $slug,
            'detail_url' => $detailUrl,
            'icon_emoji' => $mockMatch['icon_emoji'] ?? '⚙️',
            'title' => $title,
            'summary' => getCurrentLang() === 'en' ? ($mockMatch['summary_en'] ?? $mockMatch['summary'] ?? $dbService['summary']) : $dbService['summary'],
            'image_placeholder' => $dbService['image'] ? 'uploads/' . $dbService['image'] : $mockMatch['image_placeholder'],
            'dropdown_title' => !empty($dbService['details']['dropdown_title']) ? $dbService['details']['dropdown_title'] : $mockMatch['dropdown_title'],
            'subcategories' => $mappedSubcategories,
        ];
    }
    $services = $mergedServices;
} else {
    // Fallback to mock data if database is empty or still has old data
    $services = $mockServices;
}
?>
<style>
    /* 1. แอนิเมชันสำหรับสไลด์ขึ้นจากด้านล่าง (Entrance) */
    @keyframes fadeSlideUp {
        0% { opacity: 0; transform: translateY(30px); }
        100% { opacity: 1; transform: translateY(0); }
    }
    .animate-fade-up {
        opacity: 0; /* ซ่อนไว้ก่อนเริ่ม */
        animation: fadeSlideUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }
    /* 2. แอนิเมชันสำหรับตัวอักษรสีเหลือบ (Gradient Flow) */
    @keyframes text-gradient-pan {
        0% { background-position: 0% center; }
        50% { background-position: 100% center; }
        100% { background-position: 0% center; }
    }
    .animate-text-gradient {
        background-size: 200% auto;
        animation: text-gradient-pan 6s linear infinite;
    }
    /* คลาสหน่วงเวลา เพื่อให้เนื้อหาไล่ลำดับกันขึ้นมา */
    .delay-100 { animation-delay: 100ms; }
    .delay-200 { animation-delay: 200ms; }
    .delay-300 { animation-delay: 300ms; }
    .delay-400 { animation-delay: 400ms; }
    /* ซ่อนลูกศร Default ของแท็ก <summary> ในเบราว์เซอร์ต่างๆ */
    details > summary {
        list-style: none;
    }
    details > summary::-webkit-details-marker {
        display: none;
    }
    /* ซ่อนลูกศร Default ของแท็ก <summary> */
    details > summary { list-style: none; }
    details > summary::-webkit-details-marker { display: none; }
    /* แอนิเมชันสำหรับเนื้อหาด้านใน Dropdown เมื่อถูกเปิด */
    details[open] summary ~ * {
        animation: dropDownFade .3s ease-in-out forwards;
    }
    @keyframes dropDownFade {
        0% {
            opacity: 0;
            transform: translateY(-10px); /* เริ่มต้นเลื่อนขึ้นไป 10px */
        }
        100% {
            opacity: 1;
            transform: translateY(0); /* เลื่อนกลับมาตำแหน่งปกติ */
        }
    }
</style>
<section id="services-hero" class="relative font-sans bg-[#f7faff] overflow-hidden mt-0 mx-0 mb-4 sm:mt-0 sm:mx-6 sm:mb-6 rounded-t-none rounded-b-[2rem] lg:m-0 lg:rounded-none">
    <!-- Desktop Background Image -->
    <div class="absolute inset-0 z-0 hidden lg:block overflow-hidden">
        <img src="<?= e($heroImage) ?>" alt="WEBPARK Services Background" 
            class="w-full h-full object-cover object-[right_center]"
            style="filter: contrast(1.15) saturate(1.22) brightness(0.98);">
        <div class="absolute inset-0 bg-gradient-to-r from-white via-white/70 to-transparent"></div>
        <div class="absolute inset-x-0 bottom-0 h-[25%] bg-gradient-to-t from-white to-transparent z-10"></div>
    </div>
    <style>
        @keyframes fadeSlideUp {
            0% { opacity: 0; transform: translateY(40px); }
            100% { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeSlideLeft {
            0% { opacity: 0; transform: translateX(50px); }
            100% { opacity: 1; transform: translateX(0); }
        }
        .animate-entrance-up { opacity: 0; animation: fadeSlideUp 0.8s cubic-bezier(0.16,1,0.3,1) forwards; }
        .animate-entrance-left { opacity: 0; animation: fadeSlideLeft 1s cubic-bezier(0.16,1,0.3,1) forwards; }
        .delay-100 { animation-delay: 100ms; }
        .delay-200 { animation-delay: 200ms; }
        .delay-300 { animation-delay: 300ms; }
        .delay-400 { animation-delay: 400ms; }
        .delay-500 { animation-delay: 500ms; }
        @keyframes scroll { 0% { transform: translateX(0); } 100% { transform: translateX(-50%); } }
        .animate-scroll { animation: scroll 20s linear infinite; }
        .animate-scroll:hover { animation-play-state: paused; }
        
        /* iPad Pro (1024px) Overrides */
        @media (min-width: 1024px) and (max-width: 1024px) {
            .ipad-pro-services-approach-header {
                flex-direction: row !important;
                align-items: baseline !important;
                gap: 0.75rem !important;
            }
            .ipad-pro-services-approach-number { font-size: 2rem !important; }
            .ipad-pro-services-approach-title { font-size: 1.75rem !important; }
            .ipad-pro-services-approach-desc { font-size: 1.125rem !important; line-height: 1.6 !important; }
        }

        /* iPad (760px - 1366px) All Orientations & iPad Mini Landscape */
        @media (min-width: 1024px) and (max-width: 1366px) {
            .desktop-wide-container-services {
                padding-top: 7rem !important;
                padding-bottom: 7rem !important;
            }
            .ipad-pro-services-hero-content {
                max-width: 100% !important;
                margin-left: 3rem !important;
            }
            .ipad-pro-services-hero-content nav {
                margin-bottom: 1.5rem !important;
            }
            .ipad-pro-services-h1 {
                margin-bottom: 0.5rem !important;
            }
            .ipad-pro-services-text-1,
            .ipad-pro-services-text-2 {
                font-size: 4.5rem !important;
                font-weight: 900 !important;
                line-height: 1.15 !important;
                white-space: nowrap !important;
                margin-top: 0px !important;
                margin-bottom: 0px !important;
                padding-top: 0.25rem !important;
                padding-bottom: 0.25rem !important;
            }
            .ipad-pro-services-hero-p {
                font-size: 1.25rem !important;
                line-height: 1.85 !important;
                font-weight: 600 !important;
                color: #0b1b42 !important;
                max-width: 38rem !important;
                margin-top: 1.5rem !important;
                margin-bottom: 2.5rem !important;
            }
        }

        /* iPad Portrait (768px - 1023px) */
        @media (min-width: 760px) and (max-width: 1023px) {
            .desktop-wide-container-services {
                padding-top: 3.5rem !important;
                padding-bottom: 4rem !important;
            }
            .ipad-pro-services-hero-content {
                max-width: 100% !important;
                margin-left: 0 !important;
            }
            .ipad-pro-services-hero-content nav {
                margin-bottom: 1rem !important;
            }
            .ipad-pro-services-text-1,
            .ipad-pro-services-text-2 {
                font-size: 3.85rem !important;
                font-weight: 900 !important;
                line-height: 1.15 !important;
                white-space: nowrap !important;
            }
            .ipad-pro-services-hero-p {
                font-size: 1.15rem !important;
                line-height: 1.75 !important;
                margin-top: 1rem !important;
                margin-bottom: 2rem !important;
            }
        }

        /* iPad Air (820px - 1180px) Overrides */
        @media (min-width: 820px) and (max-width: 1180px) {
            .ipad-air-services-approach-header {
                flex-direction: row !important;
                align-items: baseline !important;
                gap: 0.5rem !important;
            }
            .ipad-air-services-approach-number { font-size: 1.5rem !important; }
            .ipad-air-services-approach-title { 
                font-size: 1.05rem !important; 
                line-height: 1.4 !important; 
                white-space: nowrap !important;
                letter-spacing: -0.3px !important;
            }
            .ipad-air-services-approach-desc { font-size: 1.05rem !important; line-height: 1.6 !important; }
            
            /* New grey font size overrides */
            .ipad-air-services-desc { font-size: 1.125rem !important; line-height: 1.7 !important; }
            .ipad-air-services-subtitle { white-space: normal !important; font-size: 1.5rem !important; }
            .ipad-air-service-card-desc { 
                font-size: 1.05rem !important; 
                line-height: 1.6 !important;
                display: -webkit-box !important;
                -webkit-line-clamp: 3 !important;
                -webkit-box-orient: vertical !important;
                overflow: hidden !important;
            }
            
            /* Dropdown Subcategories */
            .ipad-air-dropdown-content > a { margin-top: 0.85rem !important; }
            .ipad-air-dropdown-item { 
                font-size: 1.15rem !important; 
                padding: 0.45rem 0 !important; 
            }
        }
        
        /* Mobile (< 760px) specific fixes */
        @media (max-width: 759px) {
            .mobile-dropdown-content > a { margin-top: 0.75rem !important; }
            .mobile-dropdown-item { 
                font-size: 1.05rem !important; 
                padding: 0.4rem 0 !important; 
            }
        }
        
        /* Mobile (< 768px) Overrides */
        @media (max-width: 767px) {
            .mobile-services-approach-title {
                white-space: nowrap !important;
                font-size: 1rem !important;
                letter-spacing: -0.3px !important;
            }
        }
        
        /* iPad Mini (768px) specific fixes */
        @media (min-width: 760px) and (max-width: 819px) {
            .ipad-mini-hero-br {
                display: block !important;
            }
            .ipad-mini-services-subtitle {
                white-space: normal !important;
                font-size: 1.5rem !important;
            }
            .ipad-mini-services-approach-section { padding-top: 0 !important; }
            /* General Grey Text Sizes */
            .ipad-mini-services-desc { font-size: 1.15rem !important; line-height: 1.7 !important; }
            .ipad-mini-service-card-desc { 
                font-size: 1.05rem !important; 
                line-height: 1.6 !important;
                display: -webkit-box !important;
                -webkit-line-clamp: 3 !important;
                -webkit-box-orient: vertical !important;
                overflow: hidden !important;
            }
            .ipad-mini-approach-desc { font-size: 1.15rem !important; line-height: 1.7 !important; }
            
            /* Approach Cards */
            .ipad-mini-services-approach-card {
                padding: 1.25rem !important;
                gap: 0.75rem !important;
            }
            .ipad-mini-services-approach-icon-wrap {
                width: 3.5rem !important;
                height: 3.5rem !important;
            }
            .ipad-mini-services-approach-icon-img {
                width: 3rem !important;
                height: 3rem !important;
            }
            .ipad-mini-services-approach-header {
                display: flex !important;
                flex-direction: row !important;
                align-items: baseline !important;
                gap: 0.35rem !important;
            }
            .ipad-mini-services-approach-number { font-size: 1.25rem !important; }
            .ipad-mini-services-approach-title { 
                white-space: nowrap !important;
                font-size: 1rem !important;
                letter-spacing: -0.3px !important;
                line-height: 1.4 !important;
            }
            .ipad-mini-services-approach-desc { font-size: 1.15rem !important; line-height: 1.6 !important; }
            
            /* Dropdown Subcategories */
            .ipad-mini-dropdown-content > a { margin-top: 0.75rem !important; }
            .ipad-mini-dropdown-item { 
                font-size: 1.05rem !important; 
                padding: 0.35rem 0 !important; 
            }
        }
        
        /* Parallax: ขยายรูปเผื่อไว้ล่วงหน้า เพื่อไม่ให้เห็นขอบโหว่ตอนรูปเลื่อนตาม scroll */
        .hero-parallax-img {
            transform: scale(1.15);
            will-change: transform;
        }
        /* ไอคอนขั้นตอน Our Approach: hover แล้วขยับ+หมุนเบาๆ (ทำงานหลังจาก GSAP เคลียร์ inline transform ตอน entrance เสร็จ) */
        .gsap-approach-icon {
            transition: transform 0.3s ease;
        }
        .gsap-approach-step:hover .gsap-approach-icon {
            transform: scale(1.12) rotate(-6deg);
        }
        /* ไอคอน emoji ในการ์ดบริการ: bounce ตอน hover การ์ด */
        @keyframes iconEmojiBounce {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            30%      { transform: translateY(-6px) rotate(-10deg); }
            55%      { transform: translateY(0) rotate(8deg); }
            75%      { transform: translateY(-2px) rotate(-4deg); }
        }
        .group:hover .service-icon-emoji {
            animation: iconEmojiBounce 0.6s ease-in-out;
        }
        .service-icon-emoji {
            display: inline-block;
        }

        /* Custom Layout for all iPads (760px - 1366px) */
        @media (min-width: 760px) and (max-width: 1366px) {
            .ipad-pro-services-h1 {
                flex-direction: column !important;
                align-items: flex-start !important;
            }
            .ipad-pro-services-text-1, .ipad-pro-services-text-2 {
                margin-top: 0 !important;
                padding-top: 0 !important;
                padding-bottom: 0 !important;
                font-size: 4.25rem !important;
                line-height: 1.15 !important;
                white-space: nowrap !important;
            }
            /* Font size for Services title section matches homepage */
            .ipad-pro-services-h1-text {
                font-size: 2.5rem !important;
                line-height: 1 !important;
            }
            .ipad-pro-services-subtitle {
                font-size: 2.25rem !important;
                letter-spacing: -0.5px !important;
            }
            .ipad-pro-services-header-container {
                padding-left: 0.5rem !important; /* Shift to the left */
                padding-right: 0.5rem !important;
            }
            
            .ipad-pro-hero-btn {
                white-space: nowrap !important;
            }

            .ipad-pro-services-desc {
                font-size: 1.35rem !important; /* Adjusted to fit exactly on 2 lines */
                line-height: 1.7 !important;
                max-width: 100% !important; /* Allow full width to prevent spilling to 3rd line */
                padding-right: 0 !important;
            }

            /* Increase font size for Service Cards on iPad Pro */
            .ipad-pro-service-card-title {
                font-size: 1.75rem !important; /* Increase from text-xl */
                min-height: 4.5rem !important; /* Force 2-line height */
                display: flex;
                align-items: center;
            }
            .ipad-pro-service-card-desc {
                font-size: 1.15rem !important; /* Increase from text-sm */
                min-height: 3.5rem !important; /* Force 2-line height */
                display: -webkit-box !important;
                -webkit-line-clamp: 2 !important;
                -webkit-box-orient: vertical !important;
                overflow: hidden !important;
                text-overflow: ellipsis !important;
                line-height: 1.55 !important;
            }
            .ipad-pro-service-card-dropdown {
                font-size: 1.5rem !important;
                line-height: 1.4 !important;
                padding-top: 1.25rem !important;
                padding-bottom: 1.25rem !important;
                padding-right: 2rem !important;
                min-height: 6.5rem !important;
            }
            .ipad-pro-service-grid {
                align-items: flex-start !important;
            }
            .ipad-pro-dropdown-content > a { margin-top: 1rem !important; }
            .ipad-pro-dropdown-item {
                font-size: 1.25rem !important;
                padding: 0.5rem 0 !important;
            }
            .ipad-pro-services-approach-section {
                padding-top: 2rem !important; /* Reduce top padding */
                padding-bottom: 3rem !important;
            }
            .ipad-pro-approach-title {
                font-size: 2.35rem !important;
                line-height: 1.2 !important;
            }
            .ipad-pro-approach-desc {
                font-size: 1.05rem !important;
                line-height: 1.6 !important;
            }
            
            /* Our Approach blocks on iPad */
            .ipad-pro-services-approach-card {
                padding: 1.25rem 1.5rem !important;
                gap: 1rem !important;
            }
            .ipad-pro-services-approach-header {
                flex-direction: row !important;
                align-items: baseline !important;
                gap: 0.5rem !important;
                flex-wrap: wrap !important;
            }
            .ipad-pro-services-approach-icon-wrap {
                width: 3.5rem !important;
                height: 3.5rem !important;
            }
            .ipad-pro-services-approach-icon-img {
                width: 3rem !important;
                height: 3rem !important;
            }
            .ipad-pro-services-approach-number {
                font-size: 1.35rem !important;
                font-weight: 800 !important;
            }
            .ipad-pro-services-approach-title {
                font-size: 1.2rem !important;
                font-weight: 700 !important;
                margin-bottom: 0 !important;
            }
            .ipad-pro-services-approach-desc {
                font-size: 0.95rem !important;
                line-height: 1.55 !important;
                margin-top: 0.35rem !important;
            }
            .ipad-pro-services-hero-p {
                margin-top: 1.5rem !important;
            }
            .ipad-pro-services-hero-content {
                margin-left: 0 !important;
            }
            .ipad-pro-hidden {
                display: none !important;
            }
            .ipad-pro-services-text-1 {
                padding-bottom: 0 !important;
            }
            .ipad-pro-services-text-2 {
                padding-top: 0 !important;
                margin-top: 0 !important;
            }
        }
        
        /* iPad Mini Portrait (760px - 820px) Font Scaling */
        @media (min-width: 760px) and (max-width: 820px) {
            .ipad-pro-services-text-1, .ipad-pro-services-text-2 {
                font-size: 2.75rem !important;
            }
            .ipad-pro-services-h1-text {
                font-size: 1.85rem !important;
            }
            .ipad-pro-services-subtitle {
                font-size: 1.5rem !important;
            }
            .ipad-pro-services-desc {
                font-size: 0.95rem !important;
                line-height: 1.55 !important;
            }
            .ipad-pro-service-card-title {
                font-size: 1.15rem !important;
                min-height: 2.75rem !important;
            }
            .ipad-pro-service-card-desc {
                font-size: 0.85rem !important;
                min-height: 2.75rem !important;
            }
            .ipad-pro-service-card-dropdown {
                font-size: 0.975rem !important;
                min-height: 3.25rem !important;
            }
            .ipad-pro-dropdown-item {
                font-size: 0.9rem !important;
            }
            .ipad-pro-approach-title {
                font-size: 2rem !important;
            }
            .ipad-pro-approach-desc {
                font-size: 0.95rem !important;
            }
            .ipad-pro-services-approach-number {
                font-size: 1.2rem !important;
            }
            .ipad-pro-services-approach-title {
                font-size: 1.05rem !important;
            }
            .ipad-pro-services-approach-desc {
                font-size: 0.85rem !important;
            }
        }

        /* Dedicated Large Font Scale for iPad Pro Landscape (1024px - 1366px) */
        @media (min-width: 1024px) and (max-width: 1366px) {
            .ipad-pro-services-text-1 {
                font-size: 4.5rem !important;
                line-height: 1.35 !important;
                margin-bottom: 0.75rem !important;
                display: inline-block !important;
            }
            .ipad-pro-services-text-2 {
                font-size: 4.5rem !important;
                line-height: 1.35 !important;
                margin-bottom: 1.5rem !important;
                display: inline-block !important;
            }
            .ipad-pro-services-h1-text {
                font-size: 2.75rem !important;
            }
            .ipad-pro-services-subtitle {
                font-size: 2.5rem !important;
            }
            .ipad-pro-services-desc {
                font-size: 1.35rem !important;
                line-height: 2.1rem !important;
                margin-top: 1rem !important;
            }
            .ipad-pro-service-card-title {
                font-size: 1.85rem !important;
                min-height: 4.5rem !important;
            }
            .ipad-pro-service-card-desc {
                font-size: 1.2rem !important;
                line-height: 1.7 !important;
                min-height: 4rem !important;
            }
            .ipad-pro-service-card-dropdown {
                font-size: 1.45rem !important;
                min-height: 3.5rem !important;
            }
            .ipad-pro-dropdown-item {
                font-size: 1.35rem !important;
                line-height: 2.0rem !important;
                padding: 0.6rem 0.75rem !important;
                min-height: 2.85rem !important;
                display: flex !important;
                align-items: center !important;
                gap: 0.75rem !important;
            }
            .ipad-pro-approach-title {
                font-size: 2.5rem !important;
            }
            .ipad-pro-approach-desc {
                font-size: 1.25rem !important;
                line-height: 2.0rem !important;
            }
            .ipad-pro-services-approach-number {
                font-size: 2.0rem !important;
                font-weight: 800 !important;
            }
            .ipad-pro-services-approach-title {
                font-size: 1.45rem !important;
            }
            .ipad-pro-services-approach-desc {
                font-size: 1.15rem !important;
                line-height: 1.7 !important;
            }
        }
        
        /* Dedicated Large Font Scale for iPad Pro Portrait */
        @media (min-width: 821px) and (max-width: 1366px) and (orientation: portrait) {
            .ipad-pro-services-text-1, .ipad-pro-services-text-2 {
                font-size: 4.25rem !important;
                line-height: 1.15 !important;
            }
            .ipad-pro-services-h1-text {
                font-size: 2.75rem !important;
            }
            .ipad-pro-services-subtitle {
                font-size: 2.25rem !important;
            }
            .ipad-pro-services-desc {
                font-size: 1.35rem !important;
                line-height: 2.1rem !important;
            }
            .ipad-pro-service-grid {
                display: grid !important;
                grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
                align-items: stretch !important;
            }
            .gsap-service-card {
                height: 100% !important;
                display: flex !important;
                flex-direction: column !important;
                justify-content: space-between !important;
            }
            .desktop-service-card-inner {
                display: flex !important;
                flex-direction: column !important;
                justify-content: space-between !important;
                flex: 1 1 auto !important;
            }
            .desktop-service-emoji {
                display: inline-block !important;
                font-size: 1.75rem !important;
                margin-right: 0.5rem !important;
            }
            .ipad-pro-service-card-title {
                font-size: 1.75rem !important;
                min-height: 2.5rem !important;
                color: #022862 !important;
                font-weight: 800 !important;
            }
            .ipad-pro-service-card-desc {
                font-size: 1.15rem !important;
                line-height: 1.65rem !important;
                height: 3.35rem !important;
                min-height: 3.35rem !important;
                max-height: 3.35rem !important;
                display: -webkit-box !important;
                -webkit-line-clamp: 2 !important;
                -webkit-box-orient: vertical !important;
                overflow: hidden !important;
                text-overflow: ellipsis !important;
                margin-bottom: 0.75rem !important;
            }
            .ipad-pro-service-card-dropdown {
                font-size: 1.35rem !important;
                min-height: 3.5rem !important;
                display: flex !important;
                align-items: center !important;
                justify-content: space-between !important;
            }
            .desktop-service-summary-text {
                display: inline-block !important;
                font-size: 1.25rem !important;
                font-weight: 700 !important;
                color: #022862 !important;
                line-height: 1.4 !important;
            }
            .ipad-pro-dropdown-item {
                font-size: 1.2rem !important;
            }
            .ipad-pro-approach-title {
                font-size: 3rem !important;
            }
            .ipad-pro-approach-desc {
                font-size: 1.35rem !important;
                line-height: 1.9rem !important;
            }
            .ipad-pro-services-approach-number {
                font-size: 1.75rem !important;
            }
            .ipad-pro-services-approach-title {
                font-size: 1.5rem !important;
            }
            .ipad-pro-services-approach-desc {
                font-size: 1.15rem !important;
                line-height: 1.8rem !important;
            }
        }
        
        @media (min-width: 1025px) {
            .desktop-wide-container-services {
                max-width: 1720px !important;
                padding-left: 2.5rem !important;
                padding-right: 2.5rem !important;
            }
            .desktop-bg-vibrant-services {
                mix-blend-mode: normal !important;
                opacity: 1 !important;
            }
            .desktop-services-hero-h1 {
                font-size: 5.5rem !important;
                line-height: 1.1 !important;
                white-space: nowrap !important; /* บังคับไม่ให้ข้อความตกร่องกลางคำ */
            }
            .desktop-services-hero-text-1 {
                background: none !important;
                -webkit-text-fill-color: #475569 !important; /* สีเทาเข้ม Solid */
                color: #475569 !important;
            }
            .desktop-services-hero-text-2 {
                background: none !important;
                -webkit-text-fill-color: #2563eb !important; /* สีน้ำเงิน Solid */
                color: #2563eb !important;
            }
            .desktop-services-hero-p {
                font-size: 1.25rem !important;
                line-height: 1.75 !important;
                max-width: 34rem !important; /* ขยายความกว้างข้อความอธิบายให้สมดุล */
            }
            /* ปรับรูปแบบการ์ดบริการ (Services Grid) ให้เหมือนรูปตัวอย่างบน Desktop */
            .desktop-service-card-inner {
                flex: 1 0 auto !important; /* แก้ปัญหา height ไม่ยอมขยายตามเนื้อหา */
            }
            .desktop-service-emoji {
                display: inline-block !important;
                font-size: 1.5rem !important;
                margin-right: 0.35rem !important;
            }
            .desktop-service-title {
                color: #022862 !important;
                font-size: 1.6rem !important;
                font-weight: 800 !important;
            }
            .desktop-service-desc {
                font-size: 1.05rem !important;
                margin-bottom: 0.75rem !important;
                display: -webkit-box !important;
                -webkit-line-clamp: 2 !important;
                -webkit-box-orient: vertical !important;
                overflow: hidden !important;
                text-overflow: ellipsis !important;
                height: 3.35rem !important;
                min-height: 3.35rem !important;
                max-height: 3.35rem !important;
                line-height: 1.65rem !important;
            }
            .desktop-service-details-wrap {
                border-top: 1px solid #f1f5f9 !important;
                padding-top: 0.5rem !important;
            }
            .desktop-service-summary {
                padding: 0.5rem 0 !important;
                justify-content: space-between !important;
                margin-top: 0 !important;
                min-height: 3.25rem !important;
                display: flex !important;
                align-items: center !important;
            }
            .desktop-service-summary-text {
                display: inline-block !important;
                font-size: 1.35rem !important;
                font-weight: 800 !important;
                color: #022862 !important;
            }
            .desktop-service-arrow {
                color: #64748b !important;
                width: 1.5rem !important;
                height: 1.5rem !important;
                background-color: transparent !important;
            }
            .desktop-service-dropdown-content,
            .ipad-pro-dropdown-content {
                margin-top: 0.75rem !important;
                border-top: 1px solid #f1f5f9 !important;
                padding-top: 0.75rem !important;
                padding-bottom: 1.5rem !important;
                display: flex !important;
                flex-direction: column !important;
                gap: 0.35rem !important;
            }
            .desktop-service-dropdown-content a,
            .ipad-pro-dropdown-item {
                font-size: 1.3rem !important;
                line-height: 1.95rem !important;
                font-weight: 600 !important;
                color: #334155 !important;
                padding: 0.6rem 0.85rem !important;
                border-radius: 0.6rem !important;
                min-height: 2.85rem !important;
                display: flex !important;
                align-items: center !important;
                gap: 0.75rem !important;
                background-color: transparent !important;
                transition: all 0.2s ease !important;
            }
            .desktop-service-dropdown-content a:hover,
            .ipad-pro-dropdown-item:hover {
                background-color: #f1f5f9 !important;
                color: #043B94 !important;
                transform: translateX(4px) !important;
            }
            .desktop-service-dropdown-content a span:first-child,
            .ipad-pro-dropdown-item span:first-child {
                width: 0.55rem !important;
                height: 0.55rem !important;
                min-width: 0.55rem !important;
                min-height: 0.55rem !important;
                background-color: #94a3b8 !important;
                border-radius: 50% !important;
            }
            /* บังคับให้การ์ดและ Grid ขยายตามเนื้อหา Dropdown แน่นอน 100% */
            #gsap-services-grid, 
            .desktop-wide-container-services, 
            .gsap-service-card {
                height: auto !important;
                min-height: min-content !important; /* เปลี่ยนเป็น min-content เพื่อให้ยืดหยุ่นสุดๆ */
                overflow: visible !important; /* ป้องกันไม่ให้เนื้อหาโดนซ่อนถ้ายาวเกิน */
            }

            /* ปรับกล่องสีน้ำเงิน (CTA) ด้านล่างสุด */
            .desktop-cta-container {
                max-width: 1720px !important;
            }
            .desktop-cta-bg-img {
                width: 100% !important;
                opacity: 0.5 !important;
                background-position: center !important;
            }
            .desktop-cta-gradient-overlay {
                background: linear-gradient(to right, rgba(1, 20, 49, 0.9) 0%, rgba(4, 59, 148, 0.4) 50%, rgba(30, 64, 175, 0.2) 100%) !important;
            }
            .desktop-cta-title {
                font-size: 2.75rem !important;
            }
            .desktop-cta-desc {
                font-size: 1.15rem !important;
                max-width: none !important; /* ขยายกว้างสุดเพื่อให้อยู่บรรทัดเดียวกัน */
                text-transform: uppercase !important; /* ทำให้คำภาษาอังกฤษเป็นพิมพ์ใหญ่ตามรูป */
            }
            .desktop-cta-btn {
                padding: 1rem 2.5rem !important;
                font-size: 1.125rem !important;
                color: #0663F6 !important;
            }
            .chevron-icon {
                display: none !important;
            }
            .arrow-icon {
                display: block !important;
            }

            /* Our Approach (Desktop) */
            .desktop-approach-subtitle {
                max-width: 100% !important;
                margin-left: auto !important;
                margin-right: auto !important;
                text-align: center !important;
                white-space: nowrap !important;
            }
            .desktop-approach-subtitle span.block:not(.en-approach-line) {
                display: inline !important;
            }
            .en-approach-line {
                display: block !important;
                white-space: normal !important;
                text-align: center !important;
            }
            .desktop-approach-card {
                padding: 2.5rem 3.5rem !important;
                gap: 3rem !important;
                border-color: #bae6fd !important; /* Light blue border */
            }
            .desktop-approach-card:hover {
                border-color: #38bdf8 !important; /* Cyan border on hover */
                box-shadow: 0 10px 40px -10px rgba(56, 189, 248, 0.3) !important;
            }
            .desktop-approach-icon-wrap {
                width: 7rem !important;
                height: 7rem !important;
            }
            .desktop-approach-icon-img {
                width: 6rem !important;
                height: 6rem !important;
            }
            .desktop-approach-content {
                gap: 0.5rem !important;
                justify-content: flex-start !important;
            }
            .desktop-approach-header {
                display: flex !important;
                flex-direction: row !important;
                align-items: center !important;
                gap: 1rem !important;
                margin-bottom: 0.25rem !important;
            }
            .desktop-approach-number {
                font-size: 1.4rem !important; /* เพิ่มขนาดตัวเลข */
                margin-bottom: 0 !important;
                color: #043B94 !important;
            }
            .desktop-approach-title {
                font-size: 1.5rem !important; /* เพิ่มขนาดชื่อหัวข้อ */
                margin-bottom: 0 !important;
            }
            .desktop-approach-desc {
                font-size: 0.9rem !important;
                line-height: 1.7 !important;
                color: #64748b !important;
            }
        }

        /* Accessibility: เคารพการตั้งค่า Reduce Motion ของผู้ใช้ ลด/ปิด animation แบบ CSS ทั้งหมดในหน้านี้ */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.001ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.001ms !important;
                scroll-behavior: auto !important;
            }
        }
    </style>
    <div class="mx-auto w-full max-w-7xl px-6 sm:px-6 lg:px-8 pt-12 pb-24 lg:pt-28 lg:pb-32 relative z-10 desktop-wide-container-services">
        <!-- Mobile Background Image (Only covers this Hero container) -->
        <div class="absolute inset-0 z-0 overflow-hidden lg:hidden rounded-2xl">
            <img src="<?= e($heroImage) ?>" alt="WEBPARK Services Background" 
                class="w-full h-full object-cover object-[75%_center] md:object-[right_center]"
                style="filter: contrast(1.15) saturate(1.22) brightness(0.98);">
            <div class="absolute inset-0 bg-gradient-to-r from-white/95 via-white/70 to-transparent"></div>
            <div class="absolute inset-x-0 bottom-0 h-[25%] bg-gradient-to-t from-white to-transparent"></div>
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-[3fr_2fr] gap-12 lg:gap-20 items-center relative z-10">
            <div class="max-w-2xl lg:ml-12 xl:ml-24 ipad-pro-services-hero-content">
                <nav aria-label="Breadcrumb" class="animate-fade-up delay-100 mb-6 hidden sm:block">
                        <ol class="inline-flex items-center text-sm md:text-base font-medium text-slate-500">
                            <li>
                                <a href="<?= e(route_url('/')) ?>" class="hover:text-primary transition-colors duration-200">
                                    <?= e(t('common.nav_home')) ?>
                                </a>
                            </li>
                            <li>
                                <span class="text-slate-400" style="margin: 0 4px;">/</span>
                            </li>
                            <li aria-current="page">
                                <span class="text-slate-400"><?= e(t('common.nav_services')) ?></span>
                            </li>
                        </ol>
                    </nav>
                <h1 class="animate-fade-up delay-200 mb-2 tracking-tighter text-5xl md:text-7xl lg:text-8xl font-black leading-tight flex flex-col items-start ipad-pro-services-h1">
                    <span class="bg-gradient-to-r from-[#898F98] via-[#5d636b] to-[#000208] bg-clip-text text-transparent animate-text-gradient inline-block py-1 md:py-2 desktop-services-hero-h1 desktop-services-hero-text-1 ipad-pro-services-text-1">
                        <?= getCurrentLang() === 'th' ? 'ความเชี่ยวชาญ' : 'Expertise' ?>
                    </span>
                    <span class="bg-gradient-to-r from-[#003380] via-[#2563eb] to-[#0055ff] bg-clip-text text-transparent animate-text-gradient inline-block py-1 md:py-2 desktop-services-hero-h1 desktop-services-hero-text-2 ipad-pro-services-text-2" style="animation-delay: -3s;">
                        <?= getCurrentLang() === 'th' ? 'และจุดเด่น' : '& Strengths' ?>
                    </span>
                </h1>
                <p class="animate-fade-up delay-300 mt-6 text-[#022862] text-base md:text-lg lg:text-xl leading-relaxed max-w-2xl mb-10 font-bold md:font-semibold desktop-services-hero-p ipad-pro-services-hero-p">
                    <?php if (getCurrentLang() === 'th'): ?>
                        <span class="block md:hidden leading-relaxed">
                            มากกว่า 20 ปี ที่เราสร้างสรรค์โซลูชันดิจิทัล<br>
                            ครบวงจร ผสานเทคโนโลยี ความเชี่ยวชาญ<br>
                            และความเข้าใจธุรกิจ เพื่อเพิ่มประสิทธิภาพ<br>
                            สร้างการเติบโต และยกระดับองค์กรสู่อนาคตอย่างยั่งยืน
                        </span>
                        <span class="hidden md:block leading-relaxed">
                            มากกว่า 20 ปี ที่เราสร้างสรรค์โซลูชันดิจิทัลและ AI ครบวงจร<br>
                            เพื่อเพิ่มประสิทธิภาพ สร้างการเติบโต และยกระดับองค์กรสู่อนาคต
                        </span>
                    <?php else: ?>
                        Over 20 years of creating comprehensive digital solutions. We combine technology, expertise, and business understanding to help organizations increase efficiency and elevate into the future.
                    <?php endif; ?>
                </p>
                <div class="animate-entrance-up delay-400 flex flex-col lg:flex-row items-start gap-4">
                    <a href="<?= e(route_url('/contact')) ?>" class="inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-primary text-white text-base font-semibold rounded-full hover:bg-blue-700 transition-all shadow-md hover:-translate-y-0.5 whitespace-nowrap ipad-pro-hero-btn">
                        <?= e(getCurrentLang() === 'th' ? 'ปรึกษาผู้เชี่ยวชาญ' : 'Consult an Expert') ?>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                        </svg>
                    </a>
                    <a href="#about" class="inline-flex items-center gap-4 transition-all hover:-translate-y-0.5 group">
                        <div class="h-14 w-14 bg-white flex items-center justify-center rounded-full shadow-lg border border-slate-200 transition-all group-hover:bg-slate-50 group-hover:shadow-xl group-hover:scale-105">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-blue-600 fill-current" viewBox="0 0 24 24">
                                <path d="M8 5v14l11-7z"/>
                            </svg>
                        </div>
                        <span class="text-slate-800 text-lg font-semibold group-hover:text-primary transition-colors ipad-pro-hero-btn"><?= e(t('common.cta_watch_intro_video') !== 'common.cta_watch_intro_video' ? t('common.cta_watch_intro_video') : (getCurrentLang() === 'th' ? 'ดูวิดีโอแนะนำ' : 'Watch Video')) ?></span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="our-services" class="bg-white pt-6 pb-2 lg:pt-8 lg:pb-3 font-sans scroll-mt-6">
    <div class="mx-auto w-full max-w-7xl px-6 sm:px-6 lg:px-8 desktop-wide-container-services">
        <div class="lg:px-12 xl:px-24 ipad-pro-services-header-container">
            <h1 class="text-3xl md:text-4xl font-extrabold leading-none tracking-tight mb-0 md:mb-1 gsap-fade-up ipad-pro-services-h1-text" style="color: #0663F6 !important;">
                <?= e(t('common.nav_services') !== 'common.nav_services' ? t('common.nav_services') : (getCurrentLang() === 'th' ? 'บริการของเรา' : 'Our Services')) ?>
            </h1>
            <div class="mt-2 mb-4 md:mb-6 gsap-fade-up" style="width: 32px; height: 3px; background-color: #0663F6;"></div>
            <span class="text-lg sm:text-xl md:text-3xl font-bold gsap-fade-up w-full max-w-none mb-4 block leading-tight tracking-tight md:tracking-normal whitespace-normal md:whitespace-nowrap ipad-pro-services-subtitle ipad-air-services-subtitle ipad-mini-services-subtitle" style="color: #043B94;">
                <?= getCurrentLang() === 'th' ? 'บริการของเรา ครอบคลุมทุกมิติธุรกิจดิจิทัล' : 'Our services cover every dimension of digital business' ?>
            </span>
            <p class="gsap-fade-up text-slate-500 text-lg md:text-[15px] lg:text-base xl:text-[17px] leading-relaxed w-full max-w-none ipad-pro-services-desc ipad-air-services-desc ipad-mini-services-desc">
                <?= getCurrentLang() === 'th' ? 'Webpark ให้บริการแบบครบวงจร ตั้งแต่การวางแผน ออกแบบ พัฒนา ไปจนถึงการดูแลหลังการใช้งาน เพื่อช่วยให้องค์กรเพิ่มประสิทธิภาพ ลดต้นทุน และเติบโตได้อย่างยั่งยืนในยุคดิจิทัล' : 'Webpark provides end-to-end services, from planning, design, and development to post-deployment support. We help organizations increase efficiency, reduce costs, and grow sustainably in the digital era.' ?>
            </p>
        </div>
    </div>
</section>
<?php if (!empty($services)): ?>
<section id="gsap-services-grid" class="bg-white pt-2 pb-6 lg:pt-2 lg:pb-8 font-sans">
    <div class="mx-auto w-full max-w-7xl px-6 sm:px-6 lg:px-8 desktop-wide-container-services">
        <div class="lg:px-12 xl:px-24">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 items-start ipad-pro-service-grid">
                <?php foreach ($services as $service):
                    $sTitle  = (string)($service['title'] ?? '');
                    $sSummary= (string)($service['summary'] ?? '');
                    $sEmoji  = (string)($service['icon_emoji'] ?? '');
                    $sDetailUrl = (string)($service['detail_url'] ?? '#');
                    if ($sDetailUrl === '#' && (str_contains(strtolower($sTitle), 'digital') || str_contains(strtolower($sTitle), 'แพลตฟอร์ม'))) {
                        $sDetailUrl = route_url('/services/digital-platform');
                    }
                    if ($sDetailUrl === '#' && (str_contains(strtolower($sTitle), 'marketing') || str_contains(strtolower($sTitle), 'การตลาด') || str_contains(strtolower($sTitle), 'online'))) {
                        $sDetailUrl = route_url('/services/online-marketing');
                    }
                    if ($sDetailUrl === '#' && (str_contains(strtolower($sTitle), 'creative') || str_contains(strtolower($sTitle), 'design') || str_contains(strtolower($sTitle), 'สร้างสรรค์') || str_contains(strtolower($sTitle), 'ออกแบบ'))) {
                        $sDetailUrl = route_url('/services/creative-design');
                    }
                    $imgSrc  = resolve_article_image_url($service['image'] ?? $service['image_placeholder'] ?? '', asset_url('images/service-default.png'));
                    $subcats = (array)($service['subcategories'] ?? []);
                    $dropdownText = getCurrentLang() === 'th' ? (string)($service['dropdown_title'] ?? 'ดูหัวข้อย่อย') : (string)($service['dropdown_title'] ?? 'View Subcategories');
                ?>
                <div class="gsap-service-card group rounded-2xl border border-slate-100 bg-white overflow-hidden flex flex-col opacity-0 translate-y-10"
                    style="box-shadow: 0 2px 12px 0 rgba(4,59,148,0.07);">
                    <?php if ($sDetailUrl !== '#'): ?>
                    <a href="<?= e($sDetailUrl) ?>" class="relative w-full overflow-hidden bg-slate-50 flex items-center justify-center p-4 block group/img" style="aspect-ratio: 16/9;">
                        <img
                            src="<?= e($imgSrc) ?>"
                            alt="<?= e($sTitle) ?>"
                            class="max-h-full max-w-full w-auto h-auto object-contain transition-transform duration-500 group-hover/img:scale-105"
                            loading="lazy"
                            onerror="this.src='<?= e(asset_url('images/service-default.png')) ?>'"
                        >
                    </a>
                    <?php else: ?>
                    <div class="relative w-full overflow-hidden bg-slate-50 flex items-center justify-center p-4" style="aspect-ratio: 16/9;">
                        <img
                            src="<?= e($imgSrc) ?>"
                            alt="<?= e($sTitle) ?>"
                            class="max-h-full max-w-full w-auto h-auto object-contain transition-transform duration-500 group-hover:scale-105"
                            loading="lazy"
                            onerror="this.src='<?= e(asset_url('images/service-default.png')) ?>'"
                        >
                    </div>
                    <?php endif; ?>
                    <div class="flex flex-col flex-1 p-6 desktop-service-card-inner">
                        <div class="flex items-center gap-2 mb-2">
                            <span class="service-icon-emoji text-2xl leading-none desktop-service-emoji"><?= e($sEmoji) ?></span>
                            <?php if ($sDetailUrl !== '#'): ?>
                                <a href="<?= e($sDetailUrl) ?>" class="group/title hover:text-primary transition-colors">
                                    <h2 class="text-xl font-extrabold desktop-service-title ipad-pro-service-card-title group-hover/title:text-primary transition-colors cursor-pointer" style="color: #022862;"><?= e($sTitle) ?></h2>
                                </a>
                            <?php else: ?>
                                <h2 class="text-xl font-extrabold desktop-service-title ipad-pro-service-card-title" style="color: #022862;"><?= e($sTitle) ?></h2>
                            <?php endif; ?>
                        </div>
                        <p class="text-slate-500 text-sm leading-relaxed mb-4 desktop-service-desc ipad-pro-service-card-desc ipad-air-service-card-desc ipad-mini-service-card-desc">
                            <?= e($sSummary) ?>
                        </p>
                        <?php if ($sDetailUrl !== '#'): ?>
                        <div class="mb-4">
                            <a href="<?= e($sDetailUrl) ?>" class="inline-flex items-center gap-1.5 text-sm font-bold text-[#0663F6] hover:text-blue-700 transition-colors">
                                <span><?= getCurrentLang() === 'th' ? 'ดูรายละเอียดบริการ' : 'View Service Details' ?></span>
                                <svg class="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
                            </a>
                        </div>
                        <?php endif; ?>
                        <div class="mt-auto border-t border-slate-100 pt-3 desktop-service-details-wrap">
                            <details class="group/details">
                                <summary class="flex items-center justify-between py-2 rounded-lg text-sm font-bold cursor-pointer transition-colors duration-150 hover:text-[#043B94] text-[#022862] list-none desktop-service-summary ipad-pro-service-card-dropdown">
                                    <span class="desktop-service-summary-text"><?= e($dropdownText) ?></span>
                                    <svg class="w-4 h-4 shrink-0 text-slate-400 transition-transform duration-200 group-open/details:rotate-180 desktop-service-arrow"
                                         fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/>
                                    </svg>
                                </summary>
                                <?php if (!empty($subcats)): ?>
                                <div class="pl-3 pr-3 py-2 space-y-2 border-l-2 border-slate-100 ml-1 mt-1 mb-2 desktop-service-dropdown-content ipad-mini-dropdown-content ipad-air-dropdown-content ipad-pro-dropdown-content mobile-dropdown-content">
                                    <?php foreach ($subcats as $item):
                                        $itemLabel = (string)($item['label'] ?? '');
                                        $itemHref  = (string)($item['href'] ?? '#');
                                    ?>
                                    <a href="<?= $itemHref ?>" class="group/item flex items-center gap-2 text-sm text-slate-600 hover:text-[#043B94] transition-all duration-300 hover:translate-x-1.5 ipad-pro-dropdown-item ipad-mini-dropdown-item ipad-air-dropdown-item mobile-dropdown-item">
                                        <span class="w-1.5 h-1.5 rounded-full bg-slate-300 shrink-0 transition-all duration-300 group-hover/item:bg-[#043B94] group-hover/item:scale-125"></span>
                                        <span><?= e($itemLabel) ?></span>
                                    </a>
                                    <?php endforeach; ?>
                                </div>
                                <?php endif; ?>
                            </details>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<section class="font-sans py-4 lg:py-6">
    <div class="mx-auto w-full max-w-7xl px-6 sm:px-6 lg:px-8 desktop-wide-container-services">
        <div class="lg:px-12 xl:px-24">
            <div class="gsap-cta-box relative rounded-3xl overflow-hidden opacity-0 translate-y-10"
                style="background: linear-gradient(120deg, #011431 0%, #043B94 55%, #1e40af 100%); min-height: 200px;">
                <div class="absolute inset-0 pointer-events-none overflow-hidden">
                    <div class="absolute right-0 top-0 h-full w-1/2 desktop-cta-bg-img"
                        style="background: url('<?= e(asset_url('images/bg-cta.jpg')) ?>') center/cover no-repeat; opacity: 0.18;"></div>
                    <div class="absolute inset-0 desktop-cta-gradient-overlay"
                        style="background: linear-gradient(to right, #011431 40%, transparent 100%);"></div>
                </div>
                <div class="relative px-6 py-10 sm:px-8 sm:py-14 md:py-16 text-center" style="z-index: 10;">
                    <h2 class="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white mb-4 leading-snug desktop-cta-title">
                        <?= getCurrentLang() === 'th' ? 'พร้อมขับเคลื่อนธุรกิจของคุณไปข้างหน้าหรือยัง?' : 'Ready to drive your business forward?' ?>
                    </h2>
                    <p class="text-sm sm:text-base md:text-lg max-w-2xl mx-auto mb-8 leading-relaxed font-normal desktop-cta-desc" style="color: #bfdbfe;">
                        <?= getCurrentLang() === 'th' ? 'มาคุยกับทีม Webpark เพื่อค้นหาโซลูชันที่เหมาะกับธุรกิจของคุณ ทั้ง Digital Platform, ระบบ AI และ ERP / ERM ในมุมที่ใช้สำหรับองค์กร' : 'Talk to the Webpark team to find the right solution for your business, including Digital Platforms, AI systems, and ERP / ERM tailored for enterprise use.' ?>
                    </p>
                    <a
                        href="<?= e(route_url('/contact')) ?>"
                        class="inline-flex items-center gap-2 font-bold text-sm sm:text-base px-7 py-3 rounded-full transition-all duration-200 hover:scale-105 desktop-cta-btn"
                        style="background: #ffffff; color: #043B94; box-shadow: 0 4px 14px rgba(0,0,0,0.15);"
                        onmouseover="this.style.background='#eff6ff';"
                        onmouseout="this.style.background='#ffffff';"
                    >
                        <?= getCurrentLang() === 'th' ? 'เริ่มต้นปรึกษากับเรา' : 'Start Consulting with Us' ?>
                        <svg class="w-4 h-4 chevron-icon" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/>
                        </svg>
                        <svg class="w-5 h-5 hidden arrow-icon" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M5 12h14M12 5l7 7-7 7"/>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="our-approach" class="py-8 lg:py-12 ipad-pro-services-approach-section ipad-mini-services-approach-section" style="background-color: #f1f5f9;">
    <div class="mx-auto w-full max-w-7xl px-6 sm:px-6 lg:px-8 desktop-wide-container-services">
        <div class="lg:px-12 xl:px-24">
            <div class="text-center md:text-center mb-8 md:mb-16 flex flex-col items-center md:items-center">
                <div class="inline-flex flex-col items-start mb-3 md:mb-6">
                    <span class="text-2xl sm:text-3xl md:text-4xl font-bold gsap-fade-up mb-1 block whitespace-nowrap ipad-pro-approach-title" style="color: #054FC5 !important; -webkit-text-fill-color: #054FC5 !important; background: none !important;">
                        <?= getCurrentLang() === 'th' ? 'แนวคิดในการทำงานของเรา' : 'Our Approach' ?>
                    </span>
                    <div class="mt-1 gsap-fade-up" style="width: 32px; height: 3px; background-color: #0663F6;"></div>
                </div>
                <p class="text-slate-500 text-sm sm:text-base md:text-xl leading-relaxed max-w-4xl text-center mx-auto desktop-approach-subtitle ipad-pro-approach-desc ipad-mini-approach-desc">
                    <?php if (getCurrentLang() === 'th'): ?>
                        <span class="hidden md:block">
                            <span class="block lg:inline">กระบวนการทำงานที่เป็นระบบ เพื่อส่งมอบโซลูชันดิจิทัลที่ตอบโจทย์ธุรกิจ</span> <span class="block lg:inline">และความยั่งยืนของข้อมูลธุรกิจที่องค์กรถือครอง</span>
                        </span>
                        <span class="block md:hidden text-center text-slate-500 text-[14px] sm:text-base leading-[1.65] max-w-[330px] sm:max-w-md mx-auto" style="text-wrap: balance; overflow-wrap: break-word;">
                            กระบวนการทำงานที่เป็นระบบ เพื่อส่งมอบโซลูชันดิจิทัลที่ตอบโจทย์ธุรกิจ และความยั่งยืนของข้อมูลธุรกิจที่องค์กรถือครอง
                        </span>
                    <?php else: ?>
                        <span class="hidden md:block">
                            <span class="block en-approach-line">A systematic work process to deliver digital solutions that meet business needs</span>
                            <span class="block en-approach-line">and ensure the sustainability of business data held by the organization.</span>
                        </span>
                        <span class="block md:hidden text-center text-slate-500 text-[14px] sm:text-base leading-[1.6] max-w-[325px] sm:max-w-md mx-auto" style="text-wrap: balance; overflow-wrap: break-word;">
                            A systematic work process to deliver digital solutions that meet business needs and ensure the sustainability of business data held by the organization.
                        </span>
                    <?php endif; ?>
                </p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 lg:gap-8 max-w-5xl mx-auto desktop-approach-container">
                <?php
                $approachSteps = [
                    [
                        'number' => '01',
                        'icon'   => asset_url('images/think_1.svg'),
                        'title'  => getCurrentLang() === 'th' ? 'เข้าใจธุรกิจของคุณ' : 'Understand Your Business',
                        'desc'   => getCurrentLang() === 'th' ? 'ศึกษาความต้องการ วิเคราะห์ปัญหา และกำหนดแนวทางที่เหมาะสมกับธุรกิจของท่านอย่างแท้จริง' : 'Study requirements, analyze problems, and determine the approach that truly suits your business.',
                    ],
                    [
                        'number' => '02',
                        'icon'   => asset_url('images/think_2.svg'),
                        'title'  => getCurrentLang() === 'th' ? 'ออกแบบให้ใช้งานได้จริง' : 'Design for Practicality',
                        'desc'   => getCurrentLang() === 'th' ? 'ออกแบบประสบการณ์ใช้งานที่เน้นความง่าย และประสิทธิภาพ ตอบโจทย์ผู้ใช้งานทุกระดับ' : 'Design user experiences focusing on simplicity and efficiency, meeting the needs of users at all levels.',
                    ],
                    [
                        'number' => '03',
                        'icon'   => asset_url('images/think_3.svg'),
                        'title'  => getCurrentLang() === 'th' ? 'ดูแลอย่างต่อเนื่อง' : 'Continuous Care',
                        'desc'   => getCurrentLang() === 'th' ? 'ให้บริการหลังการขาย พร้อมทีมซัพพอร์ต และอัปเดตระบบอย่างสม่ำเสมอ' : 'Provide after-sales service with a support team and regular system updates.',
                    ],
                    [
                        'number' => '04',
                        'icon'   => asset_url('images/think_4.svg'),
                        'title'  => getCurrentLang() === 'th' ? 'รองรับการเติบโต' : 'Support Growth',
                        'desc'   => getCurrentLang() === 'th' ? 'พัฒนาระบบที่ยืดหยุ่น สามารถขยายตัว และปรับตามธุรกิจที่เติบโตในอนาคต' : 'Develop flexible systems capable of scaling and adapting as the business grows in the future.',
                    ],
                ];
                foreach ($approachSteps as $step):
                ?>
                <div class="gsap-approach-step flex flex-row items-center md:items-start gap-4 sm:gap-6 rounded-3xl border border-blue-50/50 bg-white p-5 sm:p-6 md:p-8 transition-all duration-300 opacity-0 translate-y-10 desktop-approach-card ipad-pro-services-approach-card ipad-mini-services-approach-card"
                    style="box-shadow: 0 8px 30px -10px rgba(4,59,148,0.08);">
                    <div class="gsap-approach-icon w-14 h-14 md:w-20 md:h-20 shrink-0 flex items-center justify-center md:pt-1 desktop-approach-icon-wrap ipad-pro-services-approach-icon-wrap ipad-mini-services-approach-icon-wrap">
                        <img src="<?= e($step['icon']) ?>"
                             alt="<?= e($step['title']) ?>"
                             class="w-12 h-12 md:w-16 md:h-16 object-contain drop-shadow-sm desktop-approach-icon-img ipad-pro-services-approach-icon-img ipad-mini-services-approach-icon-img"
                             onerror="this.onerror=null;this.style.display='none'">
                    </div>
                    <div class="flex flex-col gap-1 md:gap-1.5 md:pt-1 desktop-approach-content flex-1 min-w-0">
                        <div class="desktop-approach-header flex flex-row items-center gap-2 ipad-pro-services-approach-header ipad-air-services-approach-header ipad-mini-services-approach-header">
                            <span class="gsap-approach-number text-xl sm:text-2xl md:text-3xl font-extrabold desktop-approach-number ipad-pro-services-approach-number ipad-air-services-approach-number ipad-mini-services-approach-number" style="color: #043B94;"><?= e($step['number']) ?></span>
                            <h3 class="text-base sm:text-xl md:text-2xl font-extrabold mb-0 md:mb-1 desktop-approach-title ipad-pro-services-approach-title ipad-air-services-approach-title ipad-mini-services-approach-title mobile-services-approach-title leading-snug" style="color: #022862;"><?= e($step['title']) ?></h3>
                        </div>
                        <p class="text-slate-600 text-xs sm:text-base md:text-lg leading-relaxed desktop-approach-desc ipad-pro-services-approach-desc ipad-air-services-approach-desc ipad-mini-services-approach-desc"><?= e($step['desc']) ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", (event) => {
        // ลงทะเบียน ScrollTrigger
        gsap.registerPlugin(ScrollTrigger);
        // เช็คว่าผู้ใช้ตั้งค่าเครื่องให้ลด Motion ไว้หรือไม่ (Accessibility)
        // ถ้าใช่ จะข้าม animation ที่เกี่ยวกับการเคลื่อนไหวเยอะๆ (parallax, pin, elastic pop)
        // และแสดงเนื้อหาแบบปกติทันที โดยยังคง fade เบาๆ ไว้เพื่อไม่ให้กระพริบ
        const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        // 0. Parallax รูปพื้นหลัง Hero — รูปเลื่อนช้ากว่าคอนเทนต์เล็กน้อยตอน scroll ผ่าน section
        if (!prefersReducedMotion) {
            gsap.utils.toArray(".hero-parallax-img").forEach((img) => {
                gsap.to(img, {
                    yPercent: 12,
                    ease: "none",
                    scrollTrigger: {
                        trigger: "#services-hero",
                        start: "top top",
                        end: "bottom top",
                        scrub: true // ผูกตรงกับตำแหน่ง scroll แบบ real-time ไม่มี delay
                    }
                });
            });
        }
        // 1. Animation สำหรับหัวข้อ OUR SERVICES
        if (prefersReducedMotion) {
            gsap.set(".gsap-fade-up", { y: 0, opacity: 1 });
        } else {
            gsap.from(".gsap-fade-up", {
                scrollTrigger: {
                    trigger: "#our-services",
                    start: "top 85%", // เริ่มเมื่อขอบบนของ section เลื่อนมาถึง 85% ของหน้าจอ
                    toggleActions: "play none none reverse" // เล่นเมื่อเจอ ถอยกลับเมื่อเลื่อนขึ้น
                },
                y: 40,
                opacity: 0,
                duration: 0.8,
                stagger: 0.2, // ให้ h1 กับ p ค่อยๆ ขึ้นมาเหลื่อมเวลากันเล็กน้อย
                ease: "power2.out"
            });
        }
        // 2. Animation สำหรับการ์ดบริการ
        // Desktop/Tablet (≥768px): Pin ทั้ง section ไว้ แล้วให้การ์ดโผล่ทีละใบตามระยะที่เลื่อน (scrub)
        //   จนกว่าจะครบ 4 ใบ ถึงจะปลดล็อกให้เลื่อนผ่าน section นี้ไปต่อได้
        // Mobile (<768px): ใช้แบบเดิม (โผล่ทีละใบเมื่อเลื่อนมาถึง ไม่ pin) เพราะจอเล็ก pin ยาวๆ จะกระทบ UX
        const serviceCardsWrapper = document.querySelector("#gsap-services-grid");
        const serviceCards = gsap.utils.toArray(".gsap-service-card");
        if (serviceCardsWrapper && serviceCards.length && prefersReducedMotion) {
            // Reduced motion: แสดงการ์ดทั้งหมดทันที ไม่ pin ไม่ scrub
            gsap.set(serviceCards, { y: 0, opacity: 1 });
        } else if (serviceCardsWrapper && serviceCards.length) {
            ScrollTrigger.matchMedia({
                // --- Desktop / Tablet: Pin + Scrub ---
                "(min-width: 768px)": function () {
                    const cardsTimeline = gsap.timeline({
                        scrollTrigger: {
                            trigger: serviceCardsWrapper,
                            start: "top top+=80", // เผื่อระยะ header/nav ที่ sticky อยู่ด้านบน ปรับเลขนี้ตามความสูง header จริง
                            end: "+=" + (serviceCards.length * 500), // ระยะ scroll รวม ~500px ต่อการ์ด 1 ใบ ปรับได้ตามความรู้สึก
                            pin: true,
                            scrub: 1, // ค่อยๆ ตามการเลื่อน 1 วินาที ให้ความรู้สึกลื่นไหล ไม่กระตุก
                            anticipatePin: 1,
                            // markers: true, // เปิดบรรทัดนี้ตอน debug เพื่อดูตำแหน่ง start/end บนจอ
                        }
                    });
                    serviceCards.forEach((card, index) => {
                        cardsTimeline.to(card, {
                            y: 0,
                            opacity: 1,
                            duration: 1,
                            ease: "power2.out"
                        }, index); // แต่ละใบเริ่ม animate เรียงตามลำดับเวลาในไทม์ไลน์ ทำให้โผล่ทีละใบ
                    });
                    // ฟังก์ชัน cleanup: เรียกอัตโนมัติเมื่อ media query ไม่ตรงแล้ว (เช่น ย่อจอลงต่ำกว่า 768px)
                    return () => {
                        cardsTimeline.scrollTrigger && cardsTimeline.scrollTrigger.kill();
                        cardsTimeline.kill();
                    };
                },
                // --- Mobile: แบบเดิม ไม่ pin ---
                "(max-width: 767px)": function () {
                    const mobileTriggers = serviceCards.map((card) => {
                        return gsap.to(card, {
                            scrollTrigger: {
                                trigger: card,
                                start: "top 85%",
                                toggleActions: "play none none reverse"
                            },
                            y: 0,
                            opacity: 1,
                            duration: 0.6,
                            ease: "power2.out"
                        });
                    });
                    return () => {
                        mobileTriggers.forEach((tween) => {
                            tween.scrollTrigger && tween.scrollTrigger.kill();
                            tween.kill();
                        });
                    };
                }
            });
        }
        // 2.5 Animation สำหรับ CTA Box ท้ายหน้า — fade + slide ขึ้นตอน scroll มาถึง
        const ctaBox = document.querySelector(".gsap-cta-box");
        if (ctaBox) {
            if (prefersReducedMotion) {
                gsap.set(ctaBox, { y: 0, opacity: 1 });
            } else {
                gsap.to(ctaBox, {
                    scrollTrigger: {
                        trigger: ctaBox,
                        start: "top 85%",
                        toggleActions: "play none none reverse"
                    },
                    y: 0,
                    opacity: 1,
                    duration: 0.7,
                    ease: "power2.out"
                });
            }
        }
        // 3. Animation สำหรับ Our Approach
        // การ์ดทั้งใบ fade+slide ขึ้นตามปกติ ส่วนไอคอนกับเลขลำดับ (01-04) จะ "pop" ตามเข้ามาทีหลังเล็กน้อย
        // แบบ elastic ให้ความรู้สึกมีชีวิตชีวา ส่วน hover ของไอคอนคุมด้วย CSS (.gsap-approach-step:hover .gsap-approach-icon)
        const approachSteps = gsap.utils.toArray(".gsap-approach-step");
        approachSteps.forEach((step) => {
            const icon = step.querySelector(".gsap-approach-icon");
            const number = step.querySelector(".gsap-approach-number");
            if (prefersReducedMotion) {
                gsap.set(step, { y: 0, opacity: 1 });
                if (icon) gsap.set(icon, { clearProps: "opacity,transform" });
                if (number) gsap.set(number, { clearProps: "opacity,transform" });
                return;
            }
            // ตั้งค่าเริ่มต้นของไอคอน/เลข ให้เล็กและโปร่งใสก่อน pop เข้ามา
            if (icon) gsap.set(icon, { opacity: 0, scale: 0.5, rotate: 14 });
            if (number) gsap.set(number, { opacity: 0, scale: 0.3 });
            const stepTimeline = gsap.timeline({
                scrollTrigger: {
                    trigger: step, // ให้กล่อง step แต่ละอันเป็น trigger ของตัวเอง
                    start: "top 90%",
                    toggleActions: "play none none reverse"
                }
            });
            stepTimeline.to(step, {
                y: 0,
                opacity: 1,
                duration: 0.6,
                ease: "power2.out"
            });
            if (number) {
                stepTimeline.to(number, {
                    opacity: 1,
                    scale: 1,
                    duration: 0.5,
                    ease: "back.out(2.5)",
                    clearProps: "transform" // เคลียร์ inline transform หลังจบ ให้ไม่ค้างทับ hover/css อื่นภายหลัง
                }, "-=0.35");
            }
            if (icon) {
                stepTimeline.to(icon, {
                    opacity: 1,
                    scale: 1,
                    rotate: 0,
                    duration: 0.55,
                    ease: "back.out(1.7)",
                    clearProps: "transform" // เคลียร์แล้วให้ CSS hover (.gsap-approach-step:hover .gsap-approach-icon) ควบคุมต่อได้
                }, "-=0.3");
            }
        });

        // แก้ปัญหาเวลากดเปิด Dropdown แล้วความสูงเปลี่ยน แต่ GSAP ที่ Pin ไว้ไม่ยอมดันกล่องสีน้ำเงินลง
        const serviceDetails = document.querySelectorAll(".desktop-service-details-wrap details");
        serviceDetails.forEach(detail => {
            detail.addEventListener("toggle", () => {
                // ให้เวลา DOM วาดความสูงเสร็จแป๊บนึง (0 มิลลิวินาทีใน setTimeout มักจะพอ) แล้วค่อยสั่ง refresh
                setTimeout(() => {
                    ScrollTrigger.refresh();
                }, 50);
            });
        });
    });
</script>